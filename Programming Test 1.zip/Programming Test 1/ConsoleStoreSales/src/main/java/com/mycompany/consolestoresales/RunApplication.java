/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.consolestoresales;
import java.util.Scanner;
/**
 *
 * @author Student
 */
public class RunApplication {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.println("Select the beverage type");
        System.out.println("1) PS5");
        System.out.println("2) XBOX");
        System.out.println("3) SWITCH");
        System.out.print("Enter your choice (1-3): ");

        int choice;
        try {
            choice = Integer.parseInt(input.nextLine().trim());
        } catch (NumberFormatException e) {
            System.out.println("Invalid choice. Enter 1, 2, or 3.");
            return;
        }

        String consoleType;
        switch (choice) {
            case 1 -> consoleType = "PS5";
            case 2 -> consoleType = "XBOX";
            case 3 -> consoleType = "SWITCH";
            default -> {
                System.out.println("Invalid choice. Enter 1, 2, or 3.");
                return;
            }
        }

        System.out.print("Enter the store: ");
        String store = input.nextLine().trim();

        System.out.print("Enter the total sales: ");
        int totalSales;
        try {
            totalSales = Integer.parseInt(input.nextLine().trim());
        } catch (NumberFormatException e) {
            System.out.println("Total sales must be a whole number.");
            return;
        }

        if (store.isEmpty() || totalSales < 0) {
            System.out.println("Enter a store name and a non-negative sales total.");
            return;
        }

        System.out.println();
        ConsoleSales report
                = new ConsoleSales(consoleType, store, totalSales);
        report.printReport();
    }
}

