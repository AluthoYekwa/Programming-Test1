/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.gamingconsolereport;

/**
 *
 * @author Student
 */
public class GamingConsoleReport {

    public static void main(String[] args) {
        String[] cities = {"CAPE TOWN", "PORT ELIZABETH", "PRETORIA"};
        String[] consoles = {"PS5", "XBOX", "SWITCH"};

        // Each row is a city; each column is a console type.
        int[][] sales = {
            {1000, 2000, 3000},
            {2000, 3000, 4000},
            {1500, 1100, 1200}
        };

        int[] cityTotals = new int[cities.length];
        int highestTotal = -1;
        String highestCity = "";

        System.out.println("GAMING CONSOLE REPORT");
        System.out.println("------------------------------------------------");
        System.out.printf("%-20s %8s %8s %8s%n",
                "", consoles[0], consoles[1], consoles[2]);

        for (int row = 0; row < cities.length; row++) {
            System.out.printf("%-20s", cities[row]);

            for (int column = 0; column < consoles.length; column++) {
                System.out.printf(" %8d", sales[row][column]);
                cityTotals[row] += sales[row][column];
            }
            System.out.println();

            if (cityTotals[row] > highestTotal) {
                highestTotal = cityTotals[row];
                highestCity = cities[row];
            }
        }

        System.out.println("------------------------------------------------");
        System.out.println("CONSOLE SALES TOTALS FOR EACH CITY");

        for (int i = 0; i < cities.length; i++) {
            System.out.printf("%-20s %d%n", cities[i], cityTotals[i]);
        }

        System.out.println("------------------------------------------------");
        System.out.println("CITY WITH THE MOST SALES: " + highestCity);
    }
}

    
    

