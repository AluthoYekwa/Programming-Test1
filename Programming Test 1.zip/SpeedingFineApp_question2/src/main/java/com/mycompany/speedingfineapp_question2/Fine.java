/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.speedingfineapp_question2;

/**
 *
 * @author Student
 */
public abstract class Fine implements iFine{
    private String CitezenName;
    private int Speed;
    private double finePayable;
    
    public Fine(String CitizenName, int Speed) {
    this.CitezenName=CitizenName;
    this.Speed=Speed;
    CalculateFine();
}

    public String getCitezenName() {
        return CitezenName;
    }

    public int getSpeed() {
        return Speed;
    }

    public double getFinePayable() {
        return finePayable;
    }
    public void CalculateFine() {
        if(Speed>=120)
            finePayable=Speed*10.20;
    }else{
        finePayable=0;
}
    }