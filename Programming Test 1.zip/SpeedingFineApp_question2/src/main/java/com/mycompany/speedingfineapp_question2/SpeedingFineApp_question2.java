/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.speedingfineapp_question2;

/**
 *
 * @author Student
 */
public class SpeedingFineApp_question2 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
